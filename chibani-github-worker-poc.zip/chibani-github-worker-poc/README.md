# Chibani Lotfi AI — GitHub Actions Worker POC

This repository is an isolated proof-of-concept. It does NOT modify the existing
Chibani Lotfi AI / Render project.

## Goal

Validate whether a public GitHub Actions standard runner can serve as an
on-demand MoneyPrinterTurbo worker without a bank card.

Current GitHub-hosted standard runner target:

- Ubuntu 24.04
- 4 CPU
- 16 GB RAM
- 14 GB SSD
- Public repositories: standard runners are free

MoneyPrinterTurbo currently recommends Python 3.11+, minimum 4 CPU / 4 GB RAM,
recommended 6–8 CPU / 8 GB RAM, optimal 16+ GB RAM.

## What the workflow tests

1. Real runner CPU/RAM/disk
2. Network access
3. FFmpeg
4. Python 3.11
5. yt-dlp
6. Fresh MoneyPrinterTurbo checkout
7. MPT dependency installation
8. MPT CLI/dependency smoke test

## Important

This POC does NOT generate a real video yet.

That is deliberate. First we prove the compute environment works.
After a successful run, the next phase will add:

Render job -> repository_dispatch -> GitHub Action -> MPT -> Google Drive -> Render complete

No existing project files are changed in this phase.

## How to use

1. Create a NEW public GitHub repository.
2. Upload this entire POC.
3. Open Actions.
4. Run "MPT Worker POC".
5. Keep "run_mpt_smoke" = true.
6. Send me the final workflow result/screenshot.

Do not add API keys yet.
Do not add Google Drive credentials yet.
